#ifndef QEMU_7_IDA_FULL_H
#define QEMU_7_IDA_FULL_H
/* QEMU v7.0.0 x86-64 Linux ABI; IDA-oriented, dependency-free.
 * Offsets and sizes based on the supplied Clang record layouts.
 * Int128 is represented by two 64-bit words; embedded records have explicit padding.
 * Inherited fields in DeviceClass/PCIDeviceClass are flattened.
 */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed int int32_t;
typedef signed long long int64_t;
typedef uint64_t hwaddr;
typedef uint64_t pcibus_t;
typedef uint64_t qemu_ptr;
typedef struct Object Object;
typedef struct ObjectClass ObjectClass;
typedef struct DeviceState DeviceState;
typedef struct DeviceClass DeviceClass;
typedef struct PCIDevice PCIDevice;
typedef struct PCIDeviceClass PCIDeviceClass;
typedef struct PCIBus PCIBus;
typedef struct BusState BusState;
typedef struct MemoryRegion MemoryRegion;
typedef struct MemoryRegionOps MemoryRegionOps;
typedef struct AddressSpace AddressSpace;
typedef struct Error Error;
typedef struct InterfaceInfo InterfaceInfo;
typedef struct GSList GSList;
typedef struct GHashTable GHashTable;
typedef struct QDict QDict;
typedef struct Property Property;
typedef struct VMStateDescription VMStateDescription;
typedef struct RAMBlock RAMBlock;
typedef struct FlatView FlatView;
typedef struct MemoryRegionIoeventfd MemoryRegionIoeventfd;
typedef struct RamDiscardManager RamDiscardManager;
typedef struct HotplugHandler HotplugHandler;
typedef struct NamedGPIOList NamedGPIOList;
typedef struct NamedClockList NamedClockList;
typedef struct BusChild BusChild;
typedef struct SHPCDevice SHPCDevice;
typedef struct PCIEAERErr PCIEAERErr;
typedef struct TypeInfo TypeInfo;

typedef struct Int128 {
    uint64_t lo;
    uint64_t hi;
} Int128;
typedef struct ResettableState {
    uint32_t count;                 /* 0x00 */
    uint8_t hold_phase_pending;     /* 0x04 */
    uint8_t exit_phase_in_progress; /* 0x05 */
    uint8_t _pad06[2];
} ResettableState; /* 0x08 */

typedef struct Object {
    ObjectClass *klass;     /* 0x00 */
    void (*free)(Object *); /* 0x08 */
    GHashTable *properties; /* 0x10 */
    uint32_t ref;           /* 0x18 */
    uint8_t _pad1c[4];
    Object *parent; /* 0x20 */
} Object;           /* 0x28 */

typedef struct ObjectClass {
    const char *type;                 /* 0x00 */
    GSList *interfaces;               /* 0x08 */
    const char *object_cast_cache[4]; /* 0x10 */
    const char *class_cast_cache[4];  /* 0x30 */
    void (*unparent)(Object *);       /* 0x50 */
    GHashTable *properties;           /* 0x58 */
} ObjectClass;                        /* 0x60 */

typedef struct InterfaceInfo {
    const char *type;
} InterfaceInfo;

typedef struct TypeInfo {
    const char *name;                     /* 0x00 */
    const char *parent;                   /* 0x08 */
    uint64_t instance_size;               /* 0x10 */
    uint64_t instance_align;              /* 0x18 */
    void (*instance_init)(Object *);      /* 0x20 */
    void (*instance_post_init)(Object *); /* 0x28 */
    void (*instance_finalize)(Object *);  /* 0x30 */
    uint8_t abstract;                     /* 0x38 */
    uint8_t _pad39[7];
    uint64_t class_size;                            /* 0x40 */
    void (*class_init)(ObjectClass *, void *);      /* 0x48 */
    void (*class_base_init)(ObjectClass *, void *); /* 0x50 */
    void *class_data;                               /* 0x58 */
    InterfaceInfo *interfaces;                      /* 0x60 */
} TypeInfo;                                         /* 0x68 */

typedef struct DeviceState {
    Object parent_obj;             /* 0x00 */
    char *id;                      /* 0x28 */
    char *canonical_path;          /* 0x30 */
    uint8_t realized;              /* 0x38 */
    uint8_t pending_deleted_event; /* 0x39 */
    uint8_t _pad3a[6];
    int64_t pending_deleted_expires_ms;    /* 0x40 */
    QDict *opts;                           /* 0x48 */
    int32_t hotplugged;                    /* 0x50 */
    uint8_t allow_unplug_during_migration; /* 0x54 */
    uint8_t _pad55[3];
    BusState *parent_bus;               /* 0x58 */
    NamedGPIOList *gpios;               /* 0x60: LIST_HEAD */
    NamedClockList *clocks;             /* 0x68: LIST_HEAD */
    BusState *child_bus;                /* 0x70: LIST_HEAD */
    int32_t num_child_bus;              /* 0x78 */
    int32_t instance_id_alias;          /* 0x7c */
    int32_t alias_required_for_version; /* 0x80 */
    ResettableState reset;              /* 0x84 */
    uint8_t _pad8c[4];
} DeviceState; /* 0x90 */

typedef struct DeviceClass {
    const char *type;                 /* 0x00 */
    GSList *interfaces;               /* 0x08 */
    const char *object_cast_cache[4]; /* 0x10 */
    const char *class_cast_cache[4];  /* 0x30 */
    void (*unparent)(Object *);       /* 0x50 */
    GHashTable *properties;           /* 0x58 */
    uint64_t categories[1];           /* 0x60 */
    const char *fw_name;              /* 0x68 */
    const char *desc;                 /* 0x70 */
    Property *props_;                 /* 0x78 */
    uint8_t user_creatable;           /* 0x80 */
    uint8_t hotpluggable;             /* 0x81 */
    uint8_t _pad82[6];
    void (*reset)(DeviceState *);             /* 0x88 */
    void (*realize)(DeviceState *, Error **); /* 0x90 */
    void (*unrealize)(DeviceState *);         /* 0x98 */
    const VMStateDescription *vmsd;           /* 0xa0 */
    const char *bus_type;                     /* 0xa8 */
} DeviceClass;                                /* 0xb0 */

typedef struct PCIDeviceClass {
    const char *type;                 /* 0x00 */
    GSList *interfaces;               /* 0x08 */
    const char *object_cast_cache[4]; /* 0x10 */
    const char *class_cast_cache[4];  /* 0x30 */
    void (*unparent)(Object *);       /* 0x50 */
    GHashTable *properties;           /* 0x58 */
    uint64_t categories[1];           /* 0x60 */
    const char *fw_name;              /* 0x68 */
    const char *desc;                 /* 0x70 */
    Property *props_;                 /* 0x78 */
    uint8_t user_creatable;           /* 0x80 */
    uint8_t hotpluggable;             /* 0x81 */
    uint8_t _pad82[6];
    void (*reset)(DeviceState *);                               /* 0x88 */
    void (*device_realize)(DeviceState *, Error **);            /* 0x90 */
    void (*unrealize)(DeviceState *);                           /* 0x98 */
    const VMStateDescription *vmsd;                             /* 0xa0 */
    const char *bus_type;                                       /* 0xa8 */
    void (*realize)(PCIDevice *, Error **);                     /* 0xb0 */
    void (*exit)(PCIDevice *);                                  /* 0xb8 */
    uint32_t (*config_read)(PCIDevice *, uint32_t, int);        /* 0xc0 */
    void (*config_write)(PCIDevice *, uint32_t, uint32_t, int); /* 0xc8 */
    uint16_t vendor_id;                                         /* 0xd0 */
    uint16_t device_id;                                         /* 0xd2 */
    uint8_t revision;                                           /* 0xd4 */
    uint8_t _padD5;
    uint16_t class_id;            /* 0xd6 */
    uint16_t subsystem_vendor_id; /* 0xd8 */
    uint16_t subsystem_id;        /* 0xda */
    uint8_t is_bridge;            /* 0xdc */
    uint8_t _padDD[3];
    const char *romfile; /* 0xe0 */
} PCIDeviceClass;        /* 0xe8 */

/* MemTxAttrs is a packed 32-bit bitfield in QEMU; opaque for IDA. */
typedef uint32_t MemTxAttrs;
typedef int32_t MemTxResult;
typedef int32_t device_endian;
typedef struct MemoryRegionOps {
    uint64_t (*read)(void *, hwaddr, unsigned int);                                       /* 0x00 */
    void (*write)(void *, hwaddr, uint64_t, unsigned int);                                /* 0x08 */
    MemTxResult (*read_with_attrs)(void *, hwaddr, uint64_t *, unsigned int, MemTxAttrs); /* 0x10 */
    MemTxResult (*write_with_attrs)(void *, hwaddr, uint64_t, unsigned int, MemTxAttrs);  /* 0x18 */
    device_endian endianness;                                                             /* 0x20 */
    uint8_t _pad24[4];
    struct {
        uint32_t min_access_size; /* 0x28 */
        uint32_t max_access_size; /* 0x2c */
        uint8_t unaligned;        /* 0x30 */
        uint8_t _pad31[7];
        uint8_t (*accepts)(void *, hwaddr, unsigned int, uint8_t, MemTxAttrs); /* 0x38 */
    } valid;
    struct {
        uint32_t min_access_size; /* 0x40 */
        uint32_t max_access_size; /* 0x44 */
        uint8_t unaligned;        /* 0x48 */
        uint8_t _pad49[3];
    } impl;
    uint8_t _pad4c[4];
} MemoryRegionOps; /* 0x50 */

typedef struct MemoryRegion {
    Object parent_obj;            /* 0x00 */
    uint8_t romd_mode;            /* 0x28 */
    uint8_t ram;                  /* 0x29 */
    uint8_t subpage;              /* 0x2a */
    uint8_t readonly;             /* 0x2b */
    uint8_t nonvolatile;          /* 0x2c */
    uint8_t rom_device;           /* 0x2d */
    uint8_t flush_coalesced_mmio; /* 0x2e */
    uint8_t dirty_log_mask;       /* 0x2f */
    uint8_t is_iommu;             /* 0x30 */
    uint8_t _pad31[7];
    RAMBlock *ram_block;        /* 0x38 */
    Object *owner;              /* 0x40 */
    const MemoryRegionOps *ops; /* 0x48 */
    void *opaque;               /* 0x50 */
    MemoryRegion *container;    /* 0x58 */
    int32_t mapped_via_alias;   /* 0x60 */
    uint8_t _pad64[12];
    Int128 size;                        /* 0x70 */
    hwaddr addr;                        /* 0x80 */
    void (*destructor)(MemoryRegion *); /* 0x88 */
    uint64_t align;                     /* 0x90 */
    uint8_t terminates;                 /* 0x98 */
    uint8_t ram_device;                 /* 0x99 */
    uint8_t enabled;                    /* 0x9a */
    uint8_t warning_printed;            /* 0x9b */
    uint8_t vga_logging_count;          /* 0x9c */
    uint8_t _pad9d[3];
    MemoryRegion *alias; /* 0xa0 */
    hwaddr alias_offset; /* 0xa8 */
    int32_t priority;    /* 0xb0 */
    uint8_t _padb4[4];
    struct {
        MemoryRegion *first;
        void *last;
    } subregions; /* 0xb8 */
    struct {
        MemoryRegion *next;
        void *prev;
    } subregions_link; /* 0xc8 */
    struct {
        void *first;
        void *last;
    } coalesced;           /* 0xd8 */
    const char *name;      /* 0xe8 */
    uint32_t ioeventfd_nb; /* 0xf0 */
    uint8_t _padf4[4];
    MemoryRegionIoeventfd *ioeventfds; /* 0xf8 */
    RamDiscardManager *rdm;            /* 0x100 */
    uint8_t _pad108[8];
} MemoryRegion; /* 0x110; target align=16, explicit padding used */

typedef struct MemoryRegionSection {
    Int128 size;                        /* 0x00 */
    MemoryRegion *mr;                   /* 0x10 */
    FlatView *fv;                       /* 0x18 */
    hwaddr offset_within_region;        /* 0x20 */
    hwaddr offset_within_address_space; /* 0x28 */
    uint8_t readonly;                   /* 0x30 */
    uint8_t nonvolatile;                /* 0x31 */
    uint8_t _pad32[14];
} MemoryRegionSection; /* 0x40 */

typedef struct MemoryRegionPortio {
    uint32_t offset; /* 0x00 */
    uint32_t len;    /* 0x04 */
    uint32_t size;   /* 0x08 */
    uint8_t _pad0c[4];
    uint32_t (*read)(void *, uint32_t);        /* 0x10 */
    void (*write)(void *, uint32_t, uint32_t); /* 0x18 */
    uint32_t base;                             /* 0x20 */
    uint8_t _pad24[4];
} MemoryRegionPortio; /* 0x28 */

typedef struct AddressSpace {
    struct {
        void *next;
        void *func;
    } rcu;                 /* 0x00 */
    char *name;            /* 0x10 */
    MemoryRegion *root;    /* 0x18 */
    FlatView *current_map; /* 0x20 */
    int32_t ioeventfd_nb;  /* 0x28 */
    uint8_t _pad2c[4];
    MemoryRegionIoeventfd *ioeventfds; /* 0x30 */
    struct {
        void *first;
        void *last;
    } listeners; /* 0x38 */
    struct {
        void *next;
        void *prev;
    } address_spaces_link; /* 0x48 */
} AddressSpace;            /* 0x58 */

typedef struct PCIIORegion {
    pcibus_t addr; /* 0x00 */
    pcibus_t size; /* 0x08 */
    uint8_t type;  /* 0x10 */
    uint8_t _pad11[7];
    MemoryRegion *memory;        /* 0x18 */
    MemoryRegion *address_space; /* 0x20 */
} PCIIORegion;                   /* 0x28 */

typedef struct PCIReqIDCache {
    PCIDevice *dev; /* 0x00 */
    int32_t type;   /* 0x08 */
    uint8_t _pad0c[4];
} PCIReqIDCache; /* 0x10 */

typedef struct PCIExpressDevice {
    uint8_t exp_cap;       /* 0x00 */
    uint8_t pm_cap;        /* 0x01 */
    uint8_t hpev_notified; /* 0x02 */
    uint8_t _pad03;
    uint16_t aer_cap; /* 0x04 */
    uint8_t _pad06[2];
    struct {
        uint16_t log_num, log_max;
        uint8_t _pad04[4];
        PCIEAERErr *log;
    } aer_log;          /* 0x08 */
    uint16_t ats_cap;   /* 0x18 */
    uint16_t acs_cap;   /* 0x1a */
    uint16_t sriov_cap; /* 0x1c */
    uint8_t _pad1e[2];
    struct {
        uint16_t num_vfs;
        uint8_t vf_bar_type[7];
        uint8_t _pad09[7];
        const char *vfname;
        PCIDevice **vf;
    } sriov_pf; /* 0x20 */
    struct {
        PCIDevice *pf;
        uint16_t vf_number;
        uint8_t _pad0a[6];
    } sriov_vf;     /* 0x40 */
} PCIExpressDevice; /* 0x50 */

typedef struct PCIDevice {
    DeviceState qdev;             /* 0x000 */
    uint8_t partially_hotplugged; /* 0x090 */
    uint8_t has_power;            /* 0x091 */
    uint8_t _pad092[6];
    uint8_t *config;  /* 0x098 */
    uint8_t *cmask;   /* 0x0a0 */
    uint8_t *wmask;   /* 0x0a8 */
    uint8_t *w1cmask; /* 0x0b0 */
    uint8_t *used;    /* 0x0b8 */
    int32_t devfn;    /* 0x0c0 */
    uint8_t _pad0c4[4];
    PCIReqIDCache requester_id_cache;                           /* 0x0c8 */
    char name[64];                                              /* 0x0d8 */
    PCIIORegion io_regions[7];                                  /* 0x118 */
    AddressSpace bus_master_as;                                 /* 0x230 */
    uint8_t _pad288[8];                                         /* align next MemoryRegion to 16 */
    MemoryRegion bus_master_container_region;                   /* 0x290 */
    MemoryRegion bus_master_enable_region;                      /* 0x3a0 */
    uint32_t (*config_read)(PCIDevice *, uint32_t, int);        /* 0x4b0 */
    void (*config_write)(PCIDevice *, uint32_t, uint32_t, int); /* 0x4b8 */
    MemoryRegion *vga_regions[3];                               /* 0x4c0 */
    uint8_t has_vga;                                            /* 0x4d8 */
    uint8_t irq_state;                                          /* 0x4d9 */
    uint8_t _pad4da[2];
    uint32_t cap_present; /* 0x4dc */
    uint8_t msix_cap;     /* 0x4e0 */
    uint8_t _pad4e1[3];
    int32_t msix_entries_nr; /* 0x4e4 */
    uint8_t *msix_table;     /* 0x4e8 */
    uint8_t *msix_pba;       /* 0x4f0 */
    uint8_t _pad4f8[8];
    MemoryRegion msix_exclusive_bar; /* 0x500 */
    MemoryRegion msix_table_mmio;    /* 0x610 */
    MemoryRegion msix_pba_mmio;      /* 0x720 */
    uint32_t *msix_entry_used;       /* 0x830 */
    uint8_t msix_function_masked;    /* 0x838 */
    uint8_t _pad839[3];
    int32_t version_id; /* 0x83c */
    uint8_t msi_cap;    /* 0x840 */
    uint8_t _pad841[7];
    PCIExpressDevice exp; /* 0x848 */
    SHPCDevice *shpc;     /* 0x898 */
    char *romfile;        /* 0x8a0 */
    uint32_t romsize;     /* 0x8a8 */
    uint8_t has_rom;      /* 0x8ac */
    uint8_t _pad8ad[3];
    MemoryRegion rom; /* 0x8b0 */
    uint32_t rom_bar; /* 0x9c0 */
    uint8_t _pad9c4[4];
    void *intx_routing_notifier;        /* 0x9c8 */
    void *msix_vector_use_notifier;     /* 0x9d0 */
    void *msix_vector_release_notifier; /* 0x9d8 */
    void *msix_vector_poll_notifier;    /* 0x9e0 */
    char *failover_pair_id;             /* 0x9e8 */
    uint32_t acpi_index;                /* 0x9f0 */
    uint8_t _pad9f4[12];
} PCIDevice; /* 0xa00 = 2560 */

/* A partial bus type: only the common BusState prefix is grounded in supplied layout. */
typedef struct BusState {
    Object obj;                      /* 0x00 */
    DeviceState *parent;             /* 0x28 */
    char *name;                      /* 0x30 */
    HotplugHandler *hotplug_handler; /* 0x38 */
    int32_t max_index;               /* 0x40 */
    uint8_t realized;                /* 0x44 */
    uint8_t full;                    /* 0x45 */
    uint8_t _pad46[2];
    int32_t num_children; /* 0x48 */
    uint8_t _pad4c[4];
    struct {
        BusChild *first;
        void *last;
    } children; /* 0x50 */
    struct {
        BusState *next;
        BusState **prev;
    } sibling;             /* 0x60 */
    ResettableState reset; /* 0x70 */
} BusState;                /* 0x78 */

/* PCIBus layout was NOT in the supplied selected dump. Leave opaque. */

#endif /* QEMU_7_IDA_FULL_H */
