#include "qemu/osdep.h"

#include "ctf-audio.h"
#include "ctf-common.h"
#include "hw/pci/pci.h"
#include "qemu/bitops.h"
#include "qemu/module.h"

#define CTF_VENDOR_ID 0x1234
#define CTF_AUDIO_DEVICE_ID 0x1003
#define CTF_MMIO_SIZE 0x1000

static void ctf_audio_allocate(CTFAudioState *s)
{
    if (!s->buffer) {
        s->buffer = g_malloc0(sizeof(*s->buffer));
        fprintf(stderr, "[CTF] C: buffer allocated (size %zu)\n", sizeof(*s->buffer));
    }
}

static void ctf_audio_free(CTFAudioState *s)
{
    if (s->buffer) {
        fwrite("[CTF] C: buffer freed\n", 1, 22, stderr);
        g_free(s->buffer);
        s->buffer = NULL;
    }
}

static void ctf_audio_dma_write_buffer(CTFAudioState *s)
{
    uint32_t length;

    if (!s->buffer) {
        return;
    }

    length = s->dma_len;
    if (length >= sizeof(s->buffer->data)) {
        length = sizeof(s->buffer->data);
    }

    if (length) {
        pci_dma_read(&s->parent_obj, s->dma_addr, s->buffer->data, length);
    }
    fprintf(stderr, "[CTF] C: wrote %u bytes\n", length);
}

static void ctf_audio_process(CTFAudioState *s)
{
    uint32_t length;
    uint32_t sum = 0;
    unsigned int i;

    if (!s->buffer) {
        return;
    }

    length = s->buffer->length;
    if (length >= sizeof(s->buffer->data)) {
        length = sizeof(s->buffer->data);
    }

    for (i = 0; i < length; i++) {
        sum += s->buffer->data[i];
    }

    fprintf(stderr, "[CTF] C: processed %u bytes (length %u, format 0x%x, sum 0x%08x)\n", length,
            s->buffer->length, s->buffer->format, sum);
}

static uint64_t ctf_audio_mmio_read(void *opaque, hwaddr addr, unsigned int size)
{
    CTFAudioState *s = opaque;
    unsigned int byte_offset = addr & 3;
    uint32_t value;

    switch (addr & ~3ULL) {
    case 0x08:
        value = s->dma_addr;
        break;
    case 0x0c:
        value = s->dma_addr >> 32;
        break;
    case 0x10:
        value = s->dma_len;
        break;
    case 0x1c:
        value = s->buffer ? s->buffer->length : 0;
        break;
    case 0x20:
        value = s->buffer ? s->buffer->format : 0;
        break;
    case 0x24:
        value = s->buffer != NULL;
        break;
    default:
        value = 0;
        break;
    }

    return ctf_extract_register_bytes(value, byte_offset, size);
}

static void ctf_audio_mmio_write(void *opaque, hwaddr addr, uint64_t value, unsigned int size)
{
    CTFAudioState *s = opaque;
    unsigned int byte_offset = addr & 3;

    switch (addr & ~3ULL) {
    case 0x00:
        ctf_audio_allocate(s);
        break;
    case 0x04:
        ctf_audio_free(s);
        break;
    case 0x08:
        s->dma_addr = (s->dma_addr & 0xffffffff00000000ULL) |
                      ctf_deposit_register_bytes(s->dma_addr, value, byte_offset, size);
        break;
    case 0x0c:
        s->dma_addr =
            (uint32_t)s->dma_addr |
            ((uint64_t)ctf_deposit_register_bytes(s->dma_addr >> 32, value, byte_offset, size)
             << 32);
        break;
    case 0x10:
        s->dma_len = ctf_deposit_register_bytes(s->dma_len, value, byte_offset, size);
        break;
    case 0x14:
        ctf_audio_dma_write_buffer(s);
        break;
    case 0x18:
        ctf_audio_process(s);
        break;
    case 0x1c:
        if (s->buffer) {
            s->buffer->length =
                ctf_deposit_register_bytes(s->buffer->length, value, byte_offset, size);
        }
        break;
    case 0x20:
        if (s->buffer) {
            s->buffer->format =
                ctf_deposit_register_bytes(s->buffer->format, value, byte_offset, size);
        }
        break;
    default:
        break;
    }
}

static const MemoryRegionOps ctf_audio_mmio_ops = {
    .read = ctf_audio_mmio_read,
    .write = ctf_audio_mmio_write,
    .endianness = DEVICE_LITTLE_ENDIAN,
    .valid = {
        .min_access_size = 1,
        .max_access_size = 4,
        .unaligned = true,
    },
    .impl = {
        .min_access_size = 1,
        .max_access_size = 4,
    },
};

static void ctf_audio_realize(PCIDevice *pdev, Error **errp)
{
    CTFAudioState *s = CTF_AUDIO(pdev);

    pci_config_set_interrupt_pin(pdev->config, 1);
    memory_region_init_io(&s->mmio, OBJECT(s), &ctf_audio_mmio_ops, s, TYPE_CTF_AUDIO,
                          CTF_MMIO_SIZE);
    pci_register_bar(pdev, 0, PCI_BASE_ADDRESS_SPACE_MEMORY, &s->mmio);
}

static void ctf_audio_class_init(ObjectClass *klass, void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    PCIDeviceClass *k = PCI_DEVICE_CLASS(klass);

    k->realize = ctf_audio_realize;
    k->vendor_id = CTF_VENDOR_ID;
    k->device_id = CTF_AUDIO_DEVICE_ID;
    k->revision = 1;
    k->class_id = PCI_CLASS_MULTIMEDIA_AUDIO;
    dc->desc = "Audio Controller";
    set_bit(DEVICE_CATEGORY_SOUND, dc->categories);
}

static const TypeInfo ctf_audio_info = {
    .name = TYPE_CTF_AUDIO,
    .parent = TYPE_PCI_DEVICE,
    .instance_size = sizeof(CTFAudioState),
    .class_init = ctf_audio_class_init,
    .interfaces =
        (InterfaceInfo[]){
            { INTERFACE_CONVENTIONAL_PCI_DEVICE },
            {},
        },
};

static void ctf_audio_register_types(void) { type_register_static(&ctf_audio_info); }

type_init(ctf_audio_register_types)
