#include "qemu/osdep.h"

#include "ctf-common.h"
#include "ctf-msg.h"
#include "hw/pci/pci.h"
#include "qemu/bitops.h"
#include "qemu/module.h"

#define CTF_VENDOR_ID 0x1234
#define CTF_MSG_DEVICE_ID 0x1005
#define CTF_MMIO_SIZE 0x1000

static void ctf_msg_create(CTFMsgState *s)
{
    if (s->state != 1) {
        s->object = g_malloc(sizeof(*s->object));
        s->object->callback = puts;
        strcpy(s->object->message, "maybe uaf here");
        s->object->reserved = 0;
        s->state = 1;
        fprintf(stderr, "[CTF] E: object created (size %zu)\n", sizeof(*s->object));
    }
}

static void ctf_msg_free(CTFMsgState *s)
{
    if (s->state == 1) {
        fwrite("[CTF] E: object freed\n", 1, 22, stderr);
        g_free(s->object);
        s->state = 2;
    }
}

static void ctf_msg_invoke(CTFMsgState *s)
{
    if (s->object) {
        fwrite("[CTF] E: invoke\n", 1, 16, stderr);
        s->object->callback(s->object->message);
    }
}

static uint64_t ctf_msg_mmio_read(void *opaque, hwaddr addr, unsigned int size)
{
    CTFMsgState *s = opaque;
    unsigned int byte_offset = addr & 3;
    uint32_t value;

    switch (addr & ~3ULL) {
    case 0x0c:
        value = s->state == 1;
        break;
    case 0x10:
        value = sizeof(CTFMsgObject);
        break;
    default:
        value = 0;
        break;
    }

    return ctf_extract_register_bytes(value, byte_offset, size);
}

static void ctf_msg_mmio_write(void *opaque, hwaddr addr, uint64_t value, unsigned int size)
{
    CTFMsgState *s = opaque;

    switch (addr & ~3ULL) {
    case 0x00:
        ctf_msg_create(s);
        break;
    case 0x04:
        ctf_msg_free(s);
        break;
    case 0x08:
        ctf_msg_invoke(s);
        break;
    default:
        break;
    }
}

static const MemoryRegionOps ctf_msg_mmio_ops = {
    .read = ctf_msg_mmio_read,
    .write = ctf_msg_mmio_write,
    .endianness = DEVICE_LITTLE_ENDIAN,
    .valid = {
        .min_access_size = 1,
        .max_access_size = 4,
        .unaligned = true,
    },
    .impl = {
        .min_access_size = 1,
        .max_access_size = 4,
    },
};

static void ctf_msg_realize(PCIDevice *pdev, Error **errp)
{
    CTFMsgState *s = CTF_MSG(pdev);

    pci_config_set_interrupt_pin(pdev->config, 1);
    memory_region_init_io(&s->mmio, OBJECT(s), &ctf_msg_mmio_ops, s, TYPE_CTF_MSG, CTF_MMIO_SIZE);
    pci_register_bar(pdev, 0, PCI_BASE_ADDRESS_SPACE_MEMORY, &s->mmio);
}

static void ctf_msg_class_init(ObjectClass *klass, void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    PCIDeviceClass *k = PCI_DEVICE_CLASS(klass);

    k->realize = ctf_msg_realize;
    k->vendor_id = CTF_VENDOR_ID;
    k->device_id = CTF_MSG_DEVICE_ID;
    k->revision = 1;
    k->class_id = PCI_CLASS_OTHERS;
    dc->desc = "Message Controller";
    set_bit(DEVICE_CATEGORY_MISC, dc->categories);
}

static const TypeInfo ctf_msg_info = {
    .name = TYPE_CTF_MSG,
    .parent = TYPE_PCI_DEVICE,
    .instance_size = sizeof(CTFMsgState),
    .class_init = ctf_msg_class_init,
    .interfaces =
        (InterfaceInfo[]){
            { INTERFACE_CONVENTIONAL_PCI_DEVICE },
            {},
        },
};

static void ctf_msg_register_types(void) { type_register_static(&ctf_msg_info); }

type_init(ctf_msg_register_types)
