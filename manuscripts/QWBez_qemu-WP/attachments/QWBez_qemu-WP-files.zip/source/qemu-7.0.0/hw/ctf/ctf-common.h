#ifndef HW_CTF_COMMON_H
#define HW_CTF_COMMON_H

#include "qemu/timer.h"

typedef struct CTFSharedObject {
    QEMUTimer *timer;
    char message[64];
    int (*callback)(const char *message);
    uint32_t state;
    uint32_t generation;
} CTFSharedObject;

uint32_t ctf_extract_register_bytes(uint32_t value, unsigned int byte_offset, unsigned int size);
uint32_t ctf_deposit_register_bytes(uint32_t original, uint32_t value, unsigned int byte_offset,
                                    unsigned int size);

CTFSharedObject **ctf_shared_object_slot(void);
CTFSharedObject *ctf_shared_object_new(const char *tag);
void ctf_shared_object_free(CTFSharedObject *object);

#endif
