#include "qemu/osdep.h"

#include "ctf-common.h"
#include "qemu/bitops.h"
#include "qemu/timer.h"

static CTFSharedObject *ctf_shared_object;
static uint32_t ctf_shared_generation;

uint32_t ctf_extract_register_bytes(uint32_t value, unsigned int byte_offset, unsigned int size)
{
    return extract32(value, 8 * byte_offset, 8 * size);
}

uint32_t ctf_deposit_register_bytes(uint32_t original, uint32_t value, unsigned int byte_offset,
                                    unsigned int size)
{
    unsigned int shift = 8 * byte_offset;
    uint32_t mask;

    if (size > 3) {
        mask = UINT32_MAX;
    } else {
        mask = ((1U << (8 * size)) - 1) << shift;
    }

    return (original & ~mask) | (mask & (value << shift));
}

static void ctf_shared_timer_expired(void *opaque)
{
    CTFSharedObject *object = opaque;

    if (!object) {
        return;
    }

    object->state = 2;
    fprintf(stderr, "[CTF] B: timer expired (generation %u)\n", object->generation);
    object->callback(object->message);
}

CTFSharedObject **ctf_shared_object_slot(void) { return &ctf_shared_object; }

CTFSharedObject *ctf_shared_object_new(const char *tag)
{
    CTFSharedObject *object = g_new0(CTFSharedObject, 1);

    object->timer = timer_new_ms(QEMU_CLOCK_VIRTUAL, ctf_shared_timer_expired, object);
    object->callback = puts;
    strcpy(object->message, "timer fired");
    object->state = 0;
    object->generation = ++ctf_shared_generation;

    fprintf(stderr, "[CTF] %s: created timer OK (size %zu)\n", tag, sizeof(*object));
    return object;
}

void ctf_shared_object_free(CTFSharedObject *object)
{
    if (!object) {
        return;
    }

    fwrite("[CTF] B: timer freed OK\n", 1, 24, stderr);
    timer_free(object->timer);
    g_free(object);
}
