#ifndef HW_CTF_AUDIO_H
#define HW_CTF_AUDIO_H

#include "exec/memory.h"
#include "hw/pci/pci.h"

#define TYPE_CTF_AUDIO "ctf-audio"
OBJECT_DECLARE_SIMPLE_TYPE(CTFAudioState, CTF_AUDIO)

typedef struct CTFAudioBuffer {
    uint8_t data[80];
    uint32_t length;
    uint32_t format;
} CTFAudioBuffer;

struct CTFAudioState {
    PCIDevice parent_obj;
    MemoryRegion mmio;

    uint64_t dma_addr;
    uint32_t dma_len;
    uint32_t reserved0;
    CTFAudioBuffer *buffer;
    uint64_t reserved1;
};

#endif
