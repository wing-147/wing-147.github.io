#ifndef HW_CTF_LOGGER_H
#define HW_CTF_LOGGER_H

#include "hw/pci/pci.h"
#include "exec/memory.h"

#define TYPE_CTF_LOGGER "ctf-logger"
OBJECT_DECLARE_SIMPLE_TYPE(CTFLoggerState, CTF_LOGGER)

struct CTFLoggerState {
    PCIDevice parent_obj;
    MemoryRegion mmio;

    uint64_t dma_addr;
    uint32_t offset;
    uint32_t length;
    uint32_t transferred;
    uint32_t status;
    uint64_t reserved;
};

#endif
