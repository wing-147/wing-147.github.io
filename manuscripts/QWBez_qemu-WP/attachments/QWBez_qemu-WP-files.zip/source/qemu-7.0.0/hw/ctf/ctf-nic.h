#ifndef HW_CTF_NIC_H
#define HW_CTF_NIC_H

#include "hw/pci/pci.h"
#include "exec/memory.h"
#include "ctf-common.h"

#define TYPE_CTF_NIC "ctf-nic"
OBJECT_DECLARE_SIMPLE_TYPE(CTFNICState, CTF_NIC)

typedef struct CTFNICTxDesc {
    uint64_t buffer_gpa;
    uint32_t length;
    uint32_t status;
} CTFNICTxDesc;

typedef struct CTFNICRxDesc {
    uint64_t buffer1_gpa;
    uint32_t length1;
    uint32_t reserved1;
    uint64_t buffer2_gpa;
    uint32_t length2;
    uint32_t reserved2;
    uint64_t completion_gpa;
} CTFNICRxDesc;

struct CTFNICState {
    PCIDevice parent_obj;
    MemoryRegion mmio;

    CTFSharedObject **shared;
    uint64_t tx_desc_gpa;
    uint64_t rx_desc_gpa;
    uint32_t tx_ctrl;
    uint32_t rx_ctrl;
    uint32_t tx_len;
    uint32_t rx_len;
    uint32_t completion_status;
    uint32_t irq_status;
    uint8_t tx_buffer[0x800];
    uint8_t rx_buffer[0x800];
};

#endif
