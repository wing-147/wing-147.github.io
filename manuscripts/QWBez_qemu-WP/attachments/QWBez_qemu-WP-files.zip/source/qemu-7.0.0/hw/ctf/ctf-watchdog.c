#include "qemu/osdep.h"

#include "ctf-common.h"
#include "ctf-watchdog.h"
#include "hw/pci/pci.h"
#include "qemu/bitops.h"
#include "qemu/module.h"
#include "qemu/timer.h"

#define CTF_VENDOR_ID 0x1234
#define CTF_WATCHDOG_DEVICE_ID 0x1002
#define CTF_MMIO_SIZE 0x1000

static CTFSharedObject *ctf_watchdog_ensure(CTFWatchdogState *s)
{
    if (!*s->shared) {
        *s->shared = ctf_shared_object_new("B");
    }
    return *s->shared;
}

static void ctf_watchdog_arm(CTFWatchdogState *s)
{
    CTFSharedObject *object = ctf_watchdog_ensure(s);

    timer_mod(object->timer, qemu_clock_get_ms(QEMU_CLOCK_VIRTUAL) + s->timeout_ms);
    object->state = 1;
    fprintf(stderr, "[CTF] B: timer armed (%u ms)\n", s->timeout_ms);
}

static void ctf_watchdog_stop(CTFWatchdogState *s)
{
    CTFSharedObject *object = *s->shared;

    if (object) {
        timer_del(object->timer);
        object->state = 0;
        fwrite("[CTF] B: timer stopped\n", 1, 23, stderr);
    }
}

static void ctf_watchdog_reset(CTFWatchdogState *s)
{
    CTFSharedObject *old_object = *s->shared;
    CTFSharedObject *new_object = ctf_shared_object_new("B");

    if (old_object) {
        ctf_shared_object_free(old_object);
    }
    *s->shared = new_object;
    fwrite("[CTF] B: timer reset done\n", 1, 26, stderr);
}

static void ctf_watchdog_destroy(CTFWatchdogState *s)
{
    if (*s->shared) {
        ctf_shared_object_free(*s->shared);
        *s->shared = NULL;
    }
}

static void ctf_watchdog_set_message(CTFWatchdogState *s)
{
    CTFSharedObject *object = *s->shared;
    char message[64];
    uint32_t length;

    if (!object) {
        return;
    }

    length = s->message_len;
    if (length >= 63) {
        length = 63;
    }

    memset(message, 0, sizeof(message));
    if (length) {
        pci_dma_read(&s->parent_obj, s->message_gpa, message, length);
    }
    memcpy(object->message, message, length);
    object->message[length] = 0;

    fprintf(stderr, "[CTF] B: message set ('%s', len %u)\n", object->message, length);
}

static uint32_t ctf_watchdog_status(CTFWatchdogState *s)
{
    CTFSharedObject *object = *s->shared;
    uint32_t status;

    if (!object) {
        return 0;
    }

    status = 1;
    if (object->state == 1) {
        status = 3;
    }
    if (object->state == 2) {
        status |= 4;
    }
    return (object->generation << 16) | status;
}

static uint64_t ctf_watchdog_mmio_read(void *opaque, hwaddr addr, unsigned int size)
{
    CTFWatchdogState *s = opaque;
    unsigned int byte_offset = addr & 3;
    uint32_t value;

    switch (addr & ~3ULL) {
    case 0x00:
        value = s->timeout_ms;
        break;
    case 0x14:
        value = ctf_watchdog_status(s);
        break;
    case 0x18:
        value = s->message_gpa;
        break;
    case 0x1c:
        value = s->message_gpa >> 32;
        break;
    case 0x20:
        value = s->message_len;
        break;
    default:
        value = 0;
        break;
    }

    return ctf_extract_register_bytes(value, byte_offset, size);
}

static void ctf_watchdog_mmio_write(void *opaque, hwaddr addr, uint64_t value, unsigned int size)
{
    CTFWatchdogState *s = opaque;
    unsigned int byte_offset = addr & 3;

    switch (addr & ~3ULL) {
    case 0x00:
        s->timeout_ms = ctf_deposit_register_bytes(s->timeout_ms, value, byte_offset, size);
        break;
    case 0x04:
    case 0x08:
        ctf_watchdog_arm(s);
        break;
    case 0x0c:
        ctf_watchdog_stop(s);
        break;
    case 0x10:
        ctf_watchdog_reset(s);
        break;
    case 0x18:
        s->message_gpa = (s->message_gpa & 0xffffffff00000000ULL) |
                         ctf_deposit_register_bytes(s->message_gpa, value, byte_offset, size);
        break;
    case 0x1c:
        s->message_gpa =
            (uint32_t)s->message_gpa |
            ((uint64_t)ctf_deposit_register_bytes(s->message_gpa >> 32, value, byte_offset, size)
             << 32);
        break;
    case 0x20:
        s->message_len = ctf_deposit_register_bytes(s->message_len, value, byte_offset, size);
        ctf_watchdog_set_message(s);
        break;
    case 0x24:
        ctf_watchdog_ensure(s);
        break;
    case 0x28:
        ctf_watchdog_destroy(s);
        break;
    default:
        break;
    }
}

static const MemoryRegionOps ctf_watchdog_mmio_ops = {
    .read = ctf_watchdog_mmio_read,
    .write = ctf_watchdog_mmio_write,
    .endianness = DEVICE_LITTLE_ENDIAN,
    .valid = {
        .min_access_size = 1,
        .max_access_size = 4,
        .unaligned = true,
    },
    .impl = {
        .min_access_size = 1,
        .max_access_size = 4,
    },
};

static void ctf_watchdog_realize(PCIDevice *pdev, Error **errp)
{
    CTFWatchdogState *s = CTF_WATCHDOG(pdev);

    s->shared = ctf_shared_object_slot();
    s->timeout_ms = 1000;
    pci_config_set_interrupt_pin(pdev->config, 1);
    memory_region_init_io(&s->mmio, OBJECT(s), &ctf_watchdog_mmio_ops, s, TYPE_CTF_WATCHDOG,
                          CTF_MMIO_SIZE);
    pci_register_bar(pdev, 0, PCI_BASE_ADDRESS_SPACE_MEMORY, &s->mmio);
    ctf_watchdog_ensure(s);
}

static void ctf_watchdog_class_init(ObjectClass *klass, void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    PCIDeviceClass *k = PCI_DEVICE_CLASS(klass);

    k->realize = ctf_watchdog_realize;
    k->vendor_id = CTF_VENDOR_ID;
    k->device_id = CTF_WATCHDOG_DEVICE_ID;
    k->revision = 1;
    k->class_id = PCI_CLASS_SYSTEM_OTHER;
    dc->desc = "Watchdog Controller";
    set_bit(DEVICE_CATEGORY_MISC, dc->categories);
}

static const TypeInfo ctf_watchdog_info = {
    .name = TYPE_CTF_WATCHDOG,
    .parent = TYPE_PCI_DEVICE,
    .instance_size = sizeof(CTFWatchdogState),
    .class_init = ctf_watchdog_class_init,
    .interfaces =
        (InterfaceInfo[]){
            { INTERFACE_CONVENTIONAL_PCI_DEVICE },
            {},
        },
};

static void ctf_watchdog_register_types(void) { type_register_static(&ctf_watchdog_info); }

type_init(ctf_watchdog_register_types)
