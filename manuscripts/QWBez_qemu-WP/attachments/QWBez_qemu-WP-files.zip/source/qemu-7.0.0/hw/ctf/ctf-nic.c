#include "qemu/osdep.h"

#include "ctf-common.h"
#include "ctf-nic.h"
#include "hw/pci/pci.h"
#include "qemu/bitops.h"
#include "qemu/module.h"

#define CTF_VENDOR_ID 0x1234
#define CTF_NIC_DEVICE_ID 0x1001
#define CTF_MMIO_SIZE 0x1000
#define CTF_NIC_BUFFER_SIZE 0x800

static void ctf_nic_update_irq(CTFNICState *s)
{
    bool level = false;

    if (s->irq_status & 1) {
        level = (s->tx_ctrl & 2) != 0;
    }
    if ((s->irq_status & 2) && (s->rx_ctrl & 2)) {
        level = true;
    }

    if (level) {
        pci_irq_assert(&s->parent_obj);
    } else {
        pci_irq_deassert(&s->parent_obj);
    }
}

static void ctf_nic_handle_tx(CTFNICState *s)
{
    CTFSharedObject *notify_object = *s->shared;
    CTFNICTxDesc desc;
    uint32_t length;

    fwrite("[CTF] A: TX begin\n", 1, 18, stderr);
    memset(&desc, 0, sizeof(desc));

    if (pci_dma_read(&s->parent_obj, s->tx_desc_gpa, &desc, sizeof(desc))) {
        fwrite("[CTF] A: TX desc read failed\n", 1, 29, stderr);
    }

    length = desc.length;
    if (length >= CTF_NIC_BUFFER_SIZE) {
        length = CTF_NIC_BUFFER_SIZE;
    }

    if (length) {
        if (pci_dma_read(&s->parent_obj, desc.buffer_gpa, s->tx_buffer, length)) {
            fwrite("[CTF] A: TX data read failed\n", 1, 29, stderr);
        }
        memcpy(s->rx_buffer, s->tx_buffer, length);
        s->rx_len = length;
    }

    s->tx_len = length;
    desc.status = 1;
    pci_dma_write(&s->parent_obj, s->tx_desc_gpa + offsetof(CTFNICTxDesc, status), &desc.status,
                  sizeof(desc.status));

    s->completion_status |= 1;
    s->irq_status |= 1;
    ctf_nic_update_irq(s);

    fprintf(stderr, "[CTF] A: TX done (len %u)\n", length);
    fwrite("[CTF] A: TX end\n", 1, 16, stderr);
    if (notify_object) {
        notify_object->callback(notify_object->message);
    }
}

static void ctf_nic_handle_rx(CTFNICState *s)
{
    CTFSharedObject *notify_object = *s->shared;
    CTFNICRxDesc desc;
    uint32_t completion_value = 1;
    uint32_t total = 0;
    uint32_t length;

    fwrite("[CTF] A: RX begin\n", 1, 18, stderr);
    memset(&desc, 0, sizeof(desc));

    if (pci_dma_read(&s->parent_obj, s->rx_desc_gpa, &desc, sizeof(desc))) {
        fwrite("[CTF] A: RX desc read failed\n", 1, 29, stderr);
    }

    length = desc.length1;
    if (length >= CTF_NIC_BUFFER_SIZE) {
        length = CTF_NIC_BUFFER_SIZE;
    }
    if (length) {
        pci_dma_write(&s->parent_obj, desc.buffer1_gpa, s->rx_buffer, length);
        total += length;
    }

    length = desc.length2;
    if (CTF_NIC_BUFFER_SIZE - total <= length) {
        length = CTF_NIC_BUFFER_SIZE - total;
    }
    if (length) {
        pci_dma_write(&s->parent_obj, desc.buffer2_gpa, s->rx_buffer + total, length);
        total += length;
    }

    if (desc.completion_gpa) {
        pci_dma_write(&s->parent_obj, desc.completion_gpa, &completion_value,
                      sizeof(completion_value));
    }

    s->rx_len = total;
    s->completion_status |= 2;
    s->irq_status |= 2;
    ctf_nic_update_irq(s);

    fprintf(stderr, "[CTF] A: RX done (len %u)\n", total);
    fwrite("[CTF] A: RX end\n", 1, 16, stderr);
    if (notify_object) {
        notify_object->callback(notify_object->message);
    }
}

static uint64_t ctf_nic_mmio_read(void *opaque, hwaddr addr, unsigned int size)
{
    CTFNICState *s = opaque;
    unsigned int byte_offset = addr & 3;
    uint32_t value = 0;

    switch (addr & ~3ULL) {
    case 0x00:
        value = s->tx_desc_gpa;
        break;
    case 0x04:
        value = s->tx_desc_gpa >> 32;
        break;
    case 0x08:
        value = s->tx_len;
        break;
    case 0x0c:
        value = s->tx_ctrl;
        break;
    case 0x10:
        value = s->rx_desc_gpa;
        break;
    case 0x14:
        value = s->rx_desc_gpa >> 32;
        break;
    case 0x18:
        value = s->rx_len;
        break;
    case 0x1c:
        value = s->rx_ctrl;
        break;
    case 0x20:
        value = s->completion_status;
        break;
    case 0x24:
        value = s->irq_status;
        break;
    case 0x28:
        if (*s->shared) {
            value = ((*s->shared)->generation << 16) |
                    ((*s->shared)->state & 0xffff);
        } else {
            value = 0;
        }
        break;
    default:
        value = 0;
        break;
    }

    return ctf_extract_register_bytes(value, byte_offset, size);
}

static void ctf_nic_mmio_write(void *opaque, hwaddr addr, uint64_t value, unsigned int size)
{
    CTFNICState *s = opaque;
    unsigned int byte_offset = addr & 3;
    uint64_t high;

    switch (addr & ~3ULL) {
    case 0x00:
        high = s->tx_desc_gpa & 0xffffffff00000000ULL;
        s->tx_desc_gpa =
            high | ctf_deposit_register_bytes(s->tx_desc_gpa, value, byte_offset, size);
        break;
    case 0x04:
        s->tx_desc_gpa =
            (uint32_t)s->tx_desc_gpa |
            ((uint64_t)ctf_deposit_register_bytes(s->tx_desc_gpa >> 32, value, byte_offset, size)
             << 32);
        break;
    case 0x0c:
        s->tx_ctrl = ctf_deposit_register_bytes(s->tx_ctrl, value, byte_offset, size);
        if (s->tx_ctrl & 1) {
            s->tx_ctrl &= ~1U;
            s->completion_status &= ~1U;
            ctf_nic_handle_tx(s);
        }
        ctf_nic_update_irq(s);
        break;
    case 0x10:
        high = s->rx_desc_gpa & 0xffffffff00000000ULL;
        s->rx_desc_gpa =
            high | ctf_deposit_register_bytes(s->rx_desc_gpa, value, byte_offset, size);
        break;
    case 0x14:
        s->rx_desc_gpa =
            (uint32_t)s->rx_desc_gpa |
            ((uint64_t)ctf_deposit_register_bytes(s->rx_desc_gpa >> 32, value, byte_offset, size)
             << 32);
        break;
    case 0x1c:
        s->rx_ctrl = ctf_deposit_register_bytes(s->rx_ctrl, value, byte_offset, size);
        if (s->rx_ctrl & 1) {
            s->rx_ctrl &= ~1U;
            s->completion_status &= ~2U;
            ctf_nic_handle_rx(s);
        }
        ctf_nic_update_irq(s);
        break;
    case 0x24:
        s->irq_status &= ~(uint32_t)(value << (8 * byte_offset));
        ctf_nic_update_irq(s);
        break;
    default:
        break;
    }
}

static const MemoryRegionOps ctf_nic_mmio_ops = {
    .read = ctf_nic_mmio_read,
    .write = ctf_nic_mmio_write,
    .endianness = DEVICE_LITTLE_ENDIAN,
    .valid = {
        .min_access_size = 1,
        .max_access_size = 4,
        .unaligned = true,
    },
    .impl = {
        .min_access_size = 1,
        .max_access_size = 4,
    },
};

static void ctf_nic_realize(PCIDevice *pdev, Error **errp)
{
    CTFNICState *s = CTF_NIC(pdev);

    s->shared = ctf_shared_object_slot();
    pci_config_set_interrupt_pin(pdev->config, 1);
    memory_region_init_io(&s->mmio, OBJECT(s), &ctf_nic_mmio_ops, s, TYPE_CTF_NIC, CTF_MMIO_SIZE);
    pci_register_bar(pdev, 0, PCI_BASE_ADDRESS_SPACE_MEMORY, &s->mmio);
}

static void ctf_nic_class_init(ObjectClass *klass, void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    PCIDeviceClass *k = PCI_DEVICE_CLASS(klass);

    k->realize = ctf_nic_realize;
    k->vendor_id = CTF_VENDOR_ID;
    k->device_id = CTF_NIC_DEVICE_ID;
    k->revision = 1;
    k->class_id = PCI_CLASS_NETWORK_ETHERNET;
    dc->desc = "Ethernet Controller";
    set_bit(DEVICE_CATEGORY_NETWORK, dc->categories);
}

static const TypeInfo ctf_nic_info = {
    .name = TYPE_CTF_NIC,
    .parent = TYPE_PCI_DEVICE,
    .instance_size = sizeof(CTFNICState),
    .class_init = ctf_nic_class_init,
    .interfaces =
        (InterfaceInfo[]){
            { INTERFACE_CONVENTIONAL_PCI_DEVICE },
            {},
        },
};

static void ctf_nic_register_types(void) { type_register_static(&ctf_nic_info); }

type_init(ctf_nic_register_types)
