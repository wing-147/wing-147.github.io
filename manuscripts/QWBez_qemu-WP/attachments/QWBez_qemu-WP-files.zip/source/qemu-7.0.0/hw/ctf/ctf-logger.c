#include "qemu/osdep.h"

#include "ctf-common.h"
#include "ctf-logger.h"
#include "hw/pci/pci.h"
#include "qemu/bitops.h"
#include "qemu/module.h"

#define CTF_VENDOR_ID 0x1234
#define CTF_LOGGER_DEVICE_ID 0x1004
#define CTF_MMIO_SIZE 0x1000
#define CTF_LOG_PAGE_SIZE 0x1000
#define CTF_LOG_MAX_LENGTH 0x10000

static void ctf_logger_copy(CTFLoggerState *s)
{
    uint8_t page[CTF_LOG_PAGE_SIZE];
    uint32_t requested;
    size_t available;
    uint32_t transfer_length;

    requested = s->length;
    if (requested > CTF_LOG_MAX_LENGTH) {
        requested = CTF_LOG_MAX_LENGTH;
    }

    memset(page, 0, sizeof(page));
    available = sizeof(page) - s->offset;
    transfer_length = requested <= available ? requested : available;

    fprintf(stderr, "[CTF] D: copy off 0x%x len %u trans_len 0x%x\n", s->offset, requested,
            transfer_length);

    if (transfer_length) {
        pci_dma_write(&s->parent_obj, s->dma_addr, page + s->offset, transfer_length);
    }

    s->transferred = transfer_length;
    s->status |= 1;
}

static uint64_t ctf_logger_mmio_read(void *opaque, hwaddr addr, unsigned int size)
{
    CTFLoggerState *s = opaque;
    unsigned int byte_offset = addr & 3;
    uint32_t value;

    switch (addr & ~3ULL) {
    case 0x00:
        value = s->dma_addr;
        break;
    case 0x04:
        value = s->dma_addr >> 32;
        break;
    case 0x08:
        value = s->offset;
        break;
    case 0x0c:
        value = s->length;
        break;
    case 0x14:
        value = s->status;
        break;
    case 0x18:
        value = s->transferred;
        break;
    case 0x1c:
        value = CTF_LOG_PAGE_SIZE;
        break;
    default:
        value = 0;
        break;
    }

    return ctf_extract_register_bytes(value, byte_offset, size);
}

static void ctf_logger_mmio_write(void *opaque, hwaddr addr, uint64_t value, unsigned int size)
{
    CTFLoggerState *s = opaque;
    unsigned int byte_offset = addr & 3;

    switch (addr & ~3ULL) {
    case 0x00:
        s->dma_addr = (s->dma_addr & 0xffffffff00000000ULL) |
                      ctf_deposit_register_bytes(s->dma_addr, value, byte_offset, size);
        break;
    case 0x04:
        s->dma_addr =
            (uint32_t)s->dma_addr |
            ((uint64_t)ctf_deposit_register_bytes(s->dma_addr >> 32, value, byte_offset, size)
             << 32);
        break;
    case 0x08:
        s->offset = ctf_deposit_register_bytes(s->offset, value, byte_offset, size);
        break;
    case 0x0c:
        s->length = ctf_deposit_register_bytes(s->length, value, byte_offset, size);
        break;
    case 0x10:
        s->status &= ~1U;
        ctf_logger_copy(s);
        break;
    default:
        break;
    }
}

static const MemoryRegionOps ctf_logger_mmio_ops = {
    .read = ctf_logger_mmio_read,
    .write = ctf_logger_mmio_write,
    .endianness = DEVICE_LITTLE_ENDIAN,
    .valid = {
        .min_access_size = 1,
        .max_access_size = 4,
        .unaligned = true,
    },
    .impl = {
        .min_access_size = 1,
        .max_access_size = 4,
    },
};

static void ctf_logger_realize(PCIDevice *pdev, Error **errp)
{
    CTFLoggerState *s = CTF_LOGGER(pdev);

    pci_config_set_interrupt_pin(pdev->config, 1);
    memory_region_init_io(&s->mmio, OBJECT(s), &ctf_logger_mmio_ops, s, TYPE_CTF_LOGGER,
                          CTF_MMIO_SIZE);
    pci_register_bar(pdev, 0, PCI_BASE_ADDRESS_SPACE_MEMORY, &s->mmio);
}

static void ctf_logger_class_init(ObjectClass *klass, void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    PCIDeviceClass *k = PCI_DEVICE_CLASS(klass);

    k->realize = ctf_logger_realize;
    k->vendor_id = CTF_VENDOR_ID;
    k->device_id = CTF_LOGGER_DEVICE_ID;
    k->revision = 1;
    k->class_id = PCI_CLASS_OTHERS;
    dc->desc = "Log Page Controller";
    set_bit(DEVICE_CATEGORY_MISC, dc->categories);
}

static const TypeInfo ctf_logger_info = {
    .name = TYPE_CTF_LOGGER,
    .parent = TYPE_PCI_DEVICE,
    .instance_size = sizeof(CTFLoggerState),
    .class_init = ctf_logger_class_init,
    .interfaces =
        (InterfaceInfo[]){
            { INTERFACE_CONVENTIONAL_PCI_DEVICE },
            {},
        },
};

static void ctf_logger_register_types(void) { type_register_static(&ctf_logger_info); }

type_init(ctf_logger_register_types)
