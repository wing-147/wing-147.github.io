#ifndef HW_CTF_MSG_H
#define HW_CTF_MSG_H

#include "hw/pci/pci.h"
#include "exec/memory.h"

#define TYPE_CTF_MSG "ctf-msg"
OBJECT_DECLARE_SIMPLE_TYPE(CTFMsgState, CTF_MSG)

typedef struct CTFMsgObject {
    int (*callback)(const char *message);
    char message[48];
    uint64_t reserved;
} CTFMsgObject;

struct CTFMsgState {
    PCIDevice parent_obj;
    MemoryRegion mmio;

    CTFMsgObject *object;
    uint32_t state;
    uint32_t reserved;
};

#endif
