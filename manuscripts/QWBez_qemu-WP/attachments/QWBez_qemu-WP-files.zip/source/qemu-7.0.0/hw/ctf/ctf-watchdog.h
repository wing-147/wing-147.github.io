#ifndef HW_CTF_WATCHDOG_H
#define HW_CTF_WATCHDOG_H

#include "ctf-common.h"
#include "exec/memory.h"
#include "hw/pci/pci.h"

#define TYPE_CTF_WATCHDOG "ctf-watchdog"
OBJECT_DECLARE_SIMPLE_TYPE(CTFWatchdogState, CTF_WATCHDOG)

struct CTFWatchdogState {
    PCIDevice parent_obj;
    MemoryRegion mmio;

    CTFSharedObject **shared;
    uint32_t timeout_ms;
    uint32_t reserved0;
    uint64_t message_gpa;
    uint32_t message_len;
    uint32_t reserved1;
};

#endif
